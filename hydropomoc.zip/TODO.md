# Zakres realizacji

- [x] **Komunikacja awaryjna w pierwszym ekranie:** Sekcja HERO jednoznacznie komunikuje awaryjny dojazd hydraulika na terenie Warszawy w ciągu 2 godzin, rozwiązanie problemu oraz natychmiastową pomoc telefoniczną w ograniczeniu wycieku.
- [x] **Natychmiastowy kontakt:** Na telefonie i komputerze od razu widoczne są przyciski „Zadzwoń teraz” i „Napisz na WhatsApp”; strona komunikuje natychmiastowe odbieranie telefonu i możliwość uzyskania instrukcji, jak szybko ograniczyć wyciek przed przyjazdem hydraulika.
- [x] **Zakres pomocy i przebieg interwencji:** Strona prezentuje niekontrolowany wyciek, pękniętą rurę i brak możliwości zakręcenia wody, a także prosty proces: kontakt, telefoniczne zabezpieczenie usterki, dojazd i naprawa.
- [x] **Zasięg, zaufanie i responsywność:** Strona informuje o obsłudze Warszawy oraz deklarowanym czasie dojazdu, buduje zaufanie przez szybkość reakcji i fachową pomoc, a układ jest responsywny i zoptymalizowany pod pilny kontakt z urządzeń mobilnych.
