# Plan realizacji — HydroPomoc Warszawa

## Cel
Jednostronicowa, responsywna strona dla awaryjnego hydraulika w Warszawie. Pierwszy ekran ma nie pozostawiać wątpliwości: w razie wycieku lub braku możliwości zakręcenia wody klient może **zadzwonić od razu**, dostać telefoniczną instrukcję ograniczenia szkody, a hydraulik dojedzie na terenie Warszawy **w ciągu 2 godzin**.

## Zakres i działanie
- HERO z komunikatem o awarii, dojeździe do 2 h, natychmiastowym odbieraniu telefonu i dwoma stale widocznymi CTA: „Zadzwoń teraz” oraz „Napisz na WhatsApp”.
- Sekcja sytuacji awaryjnych: niekontrolowany wyciek, pęknięta rura, brak możliwości zakręcenia wody.
- Czytelny, trzyetapowy przebieg pomocy: kontakt → telefoniczne zabezpieczenie → dojazd i naprawa.
- Blok zasięgu „Warszawa i okolice” oraz obietnicą czasu dojazdu.
- Bloki zaufania, FAQ oraz końcowy panel kontaktowy. Numery i link do WhatsApp będą demonstracyjne, ponieważ nie zostały dostarczone.
- Statyczna strona bez serwera i bez formularzy; CTA używają linków `tel:` i WhatsApp, co maksymalnie skraca drogę do rozmowy na telefonie.

## Kierunek wizualny
- **Ruch projektowy:** premium service landing page, inspirowana dołączoną referencją: fotografią fachowca, mocnym granatowym tłem, czerwonym akcentem alarmowym oraz dużą ilością białej przestrzeni.
- **Zasady:** natychmiastowa hierarchia informacji, kontrolowane poczucie pilności, spokojna fachowość oraz jednoznaczne działania kontaktowe.
- **Kolor:** granat i atramentowy błękit budują spokój i kompetencję; koralowa czerwień sygnalizuje pilność i prowadzi do CTA; kość słoniowa oraz chłodna szarość dają czytelny oddech.
- **Układ:** hero na pełną szerokość z asymetrycznym tekstem po lewej i fotografią fachowca po prawej; dalej naprzemienne jasne sekcje oraz szerokie, ciemne pasy z informacją o pomocy. Na telefonie CTA są przypięte do dołu ekranu.
- **Elementy charakterystyczne:** znaczek „DO 2H”, czerwone punkty połączeń w kroku pomocy oraz techniczna linia wody jako motyw separatorów.
- **Interakcje i animacje:** przyciski reagują dyskretnym uniesieniem, a sekcje pojawiają się miękko podczas przewijania; animacje pozostają oszczędne i respektują `prefers-reduced-motion`.
- **Typografia:** `Manrope` dla nagłówków (zwarta, wyrazista geometria) i `Inter` dla tekstów użytkowych; duże, krótkie nagłówki i kontrastowe linie liczb.
- **Marka:** „HydroPomoc Warszawa — pomoc hydrauliczna, która odbiera telefon, zanim szkoda urośnie.” Osobowość: szybka, opanowana, konkretna.
- **Głos marki:** zdania są krótkie, uspokajające i rzeczowe. Przykłady: „Nie możesz zakręcić wody? Zadzwoń teraz.” oraz „Najpierw ograniczymy wyciek. Potem przyjedziemy i naprawimy problem.”
- **Logotyp:** prosty sygnet kropli zawierającej klucz nastawny, połączony z kontrastowym podpisem „HydroPomoc”; własnym kolorem rozpoznawczym marki jest **Alarm Coral #F04E45**.

## Architektura i pliki
- `dist/index.html` — kompletna semantyczna struktura strony oraz treści.
- `dist/styles.css` — responsywny styl, animacje i wariant mobilny.
- `dist/script.js` — mobilna nawigacja, płynne przewijanie oraz proste animacje wejścia.
- `dist/manus-routes.json` — manifest jedynej trasy `/`.
- `dist/assets/` — znak marki i obraz HERO z zarządzanego magazynu Manus.
- `app.config.ts` — metadane projektu z trwałym adresem logo.

## Technologia i publikacja
Statyczna strona HTML/CSS/JavaScript jest serwowana lokalnie przez prosty serwer HTTP na porcie 3000. Docelowy build wskazuje katalog `dist` bez kroku kompilacji. Nie są wymagane serwer, baza danych, dane użytkownika ani tajne zmienne środowiskowe.
